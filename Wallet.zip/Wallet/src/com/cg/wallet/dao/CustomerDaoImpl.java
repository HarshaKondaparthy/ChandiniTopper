package com.cg.wallet.dao;

import java.math.BigDecimal;
import java.util.Map;

import com.cg.wallet.bean.Customer;

public class CustomerDaoImpl implements CustomerDao {
	
	Map<String,Customer> data;
	public CustomerDaoImpl(Map<String, Customer> data) 
	{
		super();
		this.data = data;
	}

	
	public boolean save(Customer customer) {
		if(data.containsKey(customer.getMobileNo()))
		{
			data.replace(customer.getMobileNo(), customer);
		}
		else
			data.put(customer.getMobileNo(), customer);
	
		return true;
		}

	public Customer findByMobileNumber(String mobileNumber) {
		
		Customer customer=null;
		
		
		
		customer=data.get(mobileNumber);
		return customer;
		}




//	Customer updateCustomerWalletBalance(String mobileNumber,BigDecimal amount) {
//		return null;}

}
