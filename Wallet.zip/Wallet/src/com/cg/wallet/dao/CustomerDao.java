package com.cg.wallet.dao;

import java.math.BigDecimal;

import com.cg.wallet.bean.Customer;

public interface CustomerDao {
	public boolean save(Customer customer);

	Customer findByMobileNumber(String mobileNumber);

	//Customer updateCustomerWalletBalance(int mobileNumber,BigDecimal amount);

	
	

}
