package com.cg.wallet.service;

import java.math.BigDecimal;
import java.util.Map;

import com.cg.customer.exception.*;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Wallet;
import com.cg.wallet.dao.CustomerDao;
import com.cg.wallet.dao.CustomerDaoImpl;

public class CustomerServiceImpl implements CustomerService {
	private CustomerDao customerdao;
	private CustomerDao dao;
	public CustomerServiceImpl(Map<String, Customer> data){
		dao= new CustomerDaoImpl(data);
	}
	public CustomerServiceImpl(CustomerDao dao) 
	{
		super();
		this.dao = dao;
	}

	
	public Customer createAccount(String customerName,String mobileNumber, BigDecimal balance)
	{
		Customer customer=null;
		
		if(isValidName(customerName) && isValidMobile(mobileNumber) && isValidamount(balance))
		{
		customer=new Customer(customerName,mobileNumber,new Wallet(balance));
		if(dao.findByMobileNumber(mobileNumber) != null)
			throw new InvalidInputException("The account with mobile Number "+ mobileNumber+" is already created");
		dao.save(customer);
		}
		
		return customer;
	}
	
	
	
	public Customer showBalance(String mobileNumber) throws InvalidInputException
	{
		Customer customer=null;
		if(isValidMobile(mobileNumber))
		{
		  customer=dao.findByMobileNumber(mobileNumber);
		}
		if(customer == null)
			throw new InvalidInputException("The mobile Number You Entered is Not having Payment Wallet Account");
		return customer;}
	public Customer showTransactions(int mobileNumber)
	{
		return null;}

public boolean isValidName(String name) throws InvalidInputException 
{
	if( name == null)
		throw new InvalidInputException( "Sorry, Customer Name is null" );
	
	if( name.trim().isEmpty() )
		throw new InvalidInputException( "Sorry, customer Name is Empty" );
	
	return true;
}

public boolean isValidMobile(String mobileNo)throws InvalidInputException
{
	if( mobileNo == null ||  isPhoneNumberInvalid( mobileNo ))
		throw new InvalidInputException( "Sorry, Phone Number "+mobileNo+" is invalid"  );
	
	return true;
}

public boolean isValidamount(BigDecimal amount)throws InvalidInputException
{
	if( amount == null || isAmountInvalid( amount ) )
		throw new InvalidInputException( "Amount is invalid" );

	return true;
}

public boolean isAmountInvalid(BigDecimal amount) 
{
	
	if( amount.compareTo(new BigDecimal(0)) < 0) 
	{
		return true;
	}		
	else 
		return false;
}

public static boolean isPhoneNumberInvalid( String phoneNumber )
{
	if(String.valueOf(phoneNumber).matches("[1-9][0-9]{9}")) 
	{
		return false;
	}		
	else 
		return true;
}


}
