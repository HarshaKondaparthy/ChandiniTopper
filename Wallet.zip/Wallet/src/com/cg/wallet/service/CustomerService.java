package com.cg.wallet.service;

import java.math.BigDecimal;

import com.cg.wallet.bean.Customer;

public interface CustomerService
{
	public Customer createAccount(String mobileNumber,String customerName, BigDecimal amount);
	//public Customer fundTransfer(String mobileNumber, String mobileNumber1,BigDecimal amount);
	//public Customer depositAmount(String mobileNumber, BigDecimal balance);
	public Customer showBalance(String mobileNumber);
	//public Customer showTransactions(String mobileNumber);

}
