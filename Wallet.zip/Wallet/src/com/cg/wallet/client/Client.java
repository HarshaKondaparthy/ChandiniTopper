package com.cg.wallet.client;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.cg.customer.exception.InsufficientBalanceException;
import com.cg.customer.exception.InvalidInputException;
import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Wallet;
import com.cg.wallet.service.CustomerService;
import com.cg.wallet.service.CustomerServiceImpl;



public class Client {
public static void main( String[] args )
	   {
		 CustomerService customerService;
			Map<String,Customer> data=new HashMap<String, Customer>();
		
			{
				System.out.println("Welcome to Payment Wallet Application");
				customerService=new CustomerServiceImpl(data);
			}
			
		   
			String mobileNo;

			Customer customer ;

			BigDecimal bg=new BigDecimal("500.00");
			BigDecimal bg1=new BigDecimal("5000.00");
			BigDecimal bg2=new BigDecimal("600.00");
			BigDecimal bg3=new BigDecimal("800.00");
			BigDecimal bg4=new BigDecimal("900.00");
				        	Customer customer1=customerService.createAccount("chandni","8056342398", bg);
				        	System.out.println("Account is created");
				        	Customer customer2=customerService.createAccount("xyz","8056342391", bg1);
				        	System.out.println("Account is created");
				        	Customer customer3=customerService.createAccount("abcd","8056342392", bg2);
				        	System.out.println("Account is created");
				        	Customer customer4=customerService.createAccount("wxy","8056342393", bg3);
				        	System.out.println("Account is created");
				        	Customer customer5=customerService.createAccount("pqrs","8056342394", bg4);
				        	System.out.println("Account is created");

//				  System.out.print("Enter the Mobile Number : ");
//					  mobileNo=console.next();
	//Customer  customer11=customerService.showBalance("8056342398");
	customer=customerService.showBalance("8056342398");
	System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
	customer=customerService.showBalance("8056342391");
	System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
	customer=customerService.showBalance("8056342392");
	System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
	customer=customerService.showBalance("8056342393");
	System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
	customer=customerService.showBalance("8056342394");
	System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
	   }
}
